import React from 'react';

const User = ({ userData }) => {
  console.log(userData);
  const userCardStyle = {
    border: '1px solid #ccc',
    borderRadius: '8px',
    padding: '16px',
    margin: '16px',
    marginTop: '30px',
    maxWidth: '400px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
    fontFamily: 'Kanit, sans-serif',
    backgroundColor: '#fff',
  };
  

  const cardContainerStyle = {
    display: 'flex',
    alignItems: 'center',
  };

  const avatarStyle = {
    width: '100px',
    height: '100px',
    borderRadius: '50%',
    marginRight: '16px',
  };

  const userInfoStyle = {
    flex: 1,
  };

  const basicInfoStyle = {
    border: '1px solid #ddd',
    borderRadius: '4px',
    padding: '8px',
    marginTop: '16px',
  };

  const boldTextStyle = {
    fontWeight: 'bold',
    color: '#333',
  };

  return (
    <div style={userCardStyle}>
      <h2 style={boldTextStyle}>ข้อมูลนิสิต</h2>
      {userData && (
        <div>
          <div style={cardContainerStyle}>
            <img src={userData.avatar} alt="User Avatar" style={avatarStyle} />
            <div style={userInfoStyle}>
              <h2 style={boldTextStyle}>ชื่อ: {userData.firstName} {userData.lastName}!</h2>
              <p style={boldTextStyle}>รหัส: {userData.StuID}</p>
              <p style={boldTextStyle}>คณะ: {userData.faculty}</p>
              <p style={boldTextStyle}>สาขา: {userData.major}</p>
            </div>
          </div>
          <div style={basicInfoStyle}>
            <h3 style={boldTextStyle}>ข้อมูลพื้นฐาน</h3>
            {/* แสดงข้อมูลพื้นฐานที่คุณต้องการ */}
            <p style={boldTextStyle}>อายุ: {userData.ages}</p>
            <p style={boldTextStyle}>เพศ: {userData.gender}</p>
            <p style={boldTextStyle}>ศาสนา: {userData.religion}</p>
            <p style={boldTextStyle}>สัญชาติ: {userData.nationality}</p>
            {/* เพิ่มข้อมูลเพิ่มเติมตามต้องการ */}
          </div>
        </div>
      )}
    </div>
  );
};

export default User;
