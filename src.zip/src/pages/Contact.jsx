import React from 'react';

const Contact = () => {
  return (
    <div>
      <h1>แตม</h1>
      {/* เพิ่มเนื้อหาตามต้องการ */}
    </div>
  );
};

export default Contact;
